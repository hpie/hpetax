# API_System


/*
* *--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**
* SOCIAL REST API version 4.4 by Darshit - 18-04-2017 
* 
* 
* 
* -3.0 Add language feature.
* -3.1 change get/post/update/delete auth up-down.
* -3.2 change authentication for no data array 3 parameter(line 470).
* -4.0 change putmethod and deletemethod.
* -4.1 language option issue solved.
* -4.2 default language setting added. (OFF : IS_LANGUAGE) and (SET DEFAULT_LANGUAGE) init.php file changed. //define('DEFAULT_LANGUAGE', "italian");//"english".
* -4.3 issetID() method created for validate ID params.
* -4.4 Changes in MY_base remove trim() function in jsonDecode function. && add Other Headers parsing system (using Other Vars).
*
* *--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**
* By default development will show errors but testing and live will hide them.
*/
