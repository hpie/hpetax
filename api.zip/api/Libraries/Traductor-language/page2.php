<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Page 2</title>
    </head>
    <body>
        <?php
         echo $_SESSION['lang']['WORK'];
        ?>
    </body>
</html>
